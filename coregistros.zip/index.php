<?php
require 'public/index.php';